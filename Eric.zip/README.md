# 1 Admin 10 Assist 

------
- UA = `Line/7.18.0`
- LA = `CHROMEOS\t7.18.0\tiVipro\t11.12.1`
-
------

# VIPROBOT
----
Setup termux
----
- Ketik -> `pkg update`
- Ketik -> `pkg install git`
- Ketik -> `pkg install python2`
- Ketik -> `pip2 install rsa`
- Ketik -> `pip2 install thrift==0.9.3`
- Ketik -> `pip2 install requests`
- Ketik -> `pip2 install bs4`
- Ketik -> `pip2 install gtts`
- Ketik -> `pip2 install beautifulsoup`
- Ketik -> `pip2 install googletrans`
- Ketik -> `git clone https://github.com/Gendjex/vb2`
- Ketik -> `cd vb2`
- Ketik -> `python2 vb2.py`
